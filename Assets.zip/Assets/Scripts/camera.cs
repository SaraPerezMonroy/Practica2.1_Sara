using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour
{
    public Transform target;
    public float speed = 10f;
    private bool CamaraInicial = true; 


    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();   
    }

    // Update is called once per frame
    void Update()
    {
       
     if (Input.GetKeyDown(KeyCode.C))
        {
            CamaraInicial = !CamaraInicial; // esto lo que hace es asegurarse de que est� activo
        }

        if (CamaraInicial)
        {
            transform.position = Vector3.MoveTowards(transform.position, target.position + new Vector3(0f, 2f, -5f), speed * Time.deltaTime);
            transform.LookAt(target);
        }
        else
        {
            transform.position = Vector3.MoveTowards(transform.position, new Vector3(-3f, 8f, -22f), speed * Time.deltaTime);
             transform.LookAt(target); // En lugar de plano general est�tico, la c�mara tiene un ligero "paneo" para mejorar la experiencia 
        }


    }
}
