using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoJugador : MonoBehaviour
{
    public float velocidadMovimiento = 8f;
    private AudioSource audioSource;
    Rigidbody rb;
    public float jumpForce = 6f;
    bool jumping = false;
    [SerializeField] GameObject pantallaDerrota;

    // Start is called before the first frame update
    void Start()
    {
        transform.Translate(2f, 0f, -2f);
        audioSource = GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody>();
        rb.useGravity = true;
    }

    // Update is called once per frame
    void Update()
    {
        float movimientoEjeX = Input.GetAxis("Horizontal") * velocidadMovimiento * Time.deltaTime;
        float movimientoEjeY = Input.GetAxis("Vertical") * velocidadMovimiento * Time.deltaTime;

        if (Input.GetButtonDown("Jump") && !jumping) // Para el salto
        {
            Jump();
        }

        // Mueve el jugador
        Vector3 movimiento = new Vector3(movimientoEjeX, 0, movimientoEjeY);
        transform.Translate(movimiento);

        if (gameObject.transform.position.y < -3.5f) // Para que muera cuando est� por debajo de -3.5
        {
            Time.timeScale = 0;
            pantallaDerrota.SetActive(true);
        }

        if (Input.GetKeyDown(KeyCode.E)) // Esto es para cuando est� en el cubo
        {
            rb.useGravity = true;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Coin"))
        {
            if (audioSource != null)
            {
                audioSource.Play();
            }
        }

        if (other.CompareTag("Antigravity"))
        {
            Antigravity antigravityScript = other.GetComponent<Antigravity>(); // Obtener el script Antigravity

            if (antigravityScript != null)
            {
                transform.position = antigravityScript.GetCenterPosition(); // Centrar al jugador en la posici�n del objeto Antigravity
            }

            rb.useGravity = false;
        }
    }

    void Jump()
    {
        if (rb)
        {
            jumping = true;
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Suelo"))
        {
            jumping = false;
        }
    }
}
