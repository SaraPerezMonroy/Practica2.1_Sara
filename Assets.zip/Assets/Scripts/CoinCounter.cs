using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CoinCounter : MonoBehaviour
{
    public static CoinCounter instance;
    public TMP_Text coinText;
    public int currentCoins = 0; // Para las monedas que consigue el jugador
    private int totalCoins = 0; // Variable para rastrear la cantidad total de monedas conseguidas

    private AudioSource audioSource;

    // Tiempo de partida y detener movimiento
    float tiempoDePartida = 0.0f;
    bool estaJugando = true;

    [SerializeField]
    GameObject pantallaFinal;

    [SerializeField]
    TextMeshProUGUI textLabelTime;

    [SerializeField]
    GameObject puente;

    void Awake()
    {
        instance = this; // Las monedas que tiene en el momento
    }

    void Start()
    {
        coinText.text = "x " + currentCoins.ToString("00");
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (estaJugando == true)
        {
            tiempoDePartida = tiempoDePartida + Time.deltaTime;
        }  
        
        if (totalCoins == 9)
            {
               pantallaFinal.SetActive(true);
               Time.timeScale = 0;
               textLabelTime.text = tiempoDePartida.ToString("0.0") + " segundos";
                CoinCounter coinCounter = FindObjectOfType<CoinCounter>();
                int totalCoins = coinCounter.GetTotalCoins();        
                audioSource.Stop();
            }

        if (totalCoins == 4)
        {
            puente.SetActive(true);
        }
    }

    public void IncreaseCoins(int cantidad)
    {
        currentCoins += cantidad;
        totalCoins += cantidad; // Aumentar la cantidad total
        coinText.text = "x " + currentCoins.ToString("00"); // Con esto se va ense�ando las monedas que se van ganando
    }

    public int GetTotalCoins() // M�todo para obtener la cantidad total de monedas
    {
        return totalCoins;
    }
}
