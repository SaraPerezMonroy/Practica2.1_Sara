using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Antigravity : MonoBehaviour
{
    public float velocidadMovimiento = 8f;
    public float speed = 100f;
    public Transform target;
    bool jugadorDentro = false;
    Vector3 startPosition;
    Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        startPosition = transform.position;

        // Obtener la referencia al Rigidbody.
        rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.useGravity = false; // Desactivar la gravedad al inicio.
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (jugadorDentro)
        {
            transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            jugadorDentro = false;
            transform.position = startPosition;

            if (rb != null)
            {
                rb.useGravity = true;
            }
        }
    }


    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Player")
        {
            jugadorDentro = true;
        }
    }
    public Vector3 GetCenterPosition()
    {
        return transform.position;
    }
}
