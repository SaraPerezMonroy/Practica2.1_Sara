using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coins : MonoBehaviour
{
    public int value;

    public GameObject ParticleSystem;
    float rotateY = 100f;

    void Start()
    {
        value = 1;
    }

    void Update()
    {
        transform.Rotate(0, rotateY * Time.deltaTime, 0);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other != null && other.gameObject.CompareTag("Player"))
        {            
            Instantiate(ParticleSystem, gameObject.transform.position, new Quaternion());
            Destroy(gameObject);

            if (CoinCounter.instance != null)
            {
                CoinCounter.instance.IncreaseCoins(value);
            }

        }
    }
}
