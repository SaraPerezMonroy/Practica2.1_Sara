using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class BotonReiniciar : MonoBehaviour
{
    void Start()
    {
    }

    void Update()
    {
    }

    // Para poder reiniciar el juego
    public void ReiniciarJuego()
    {
        GameObject.Find("Jugador").transform.position = new Vector3(2f, 0f, -2f);

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;

    }

}
